# TEED
Simple and minimal text editor made in python
